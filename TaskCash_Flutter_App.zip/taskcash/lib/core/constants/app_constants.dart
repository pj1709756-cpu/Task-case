// lib/core/constants/app_constants.dart

class AppConstants {
  // App Info
  static const String appName = 'TaskCash';
  static const String appVersion = '1.0.0';
  static const String appTagline = 'Earn while you play';

  // Firestore Collections
  static const String usersCollection = 'users';
  static const String tasksCollection = 'tasks';
  static const String userTasksCollection = 'user_tasks';
  static const String transactionsCollection = 'transactions';
  static const String withdrawalsCollection = 'withdrawals';
  static const String referralsCollection = 'referrals';
  static const String announcementsCollection = 'announcements';
  static const String settingsCollection = 'settings';
  static const String coinsHistoryCollection = 'coins_history';

  // Coin Values
  static const int dailyTaskCoins = 50;
  static const int quizTaskCoins = 100;
  static const int checkInCoins = 20;
  static const int watchAdCoins = 30;
  static const int referralCoins = 500;
  static const int referralBonusCoins = 200;
  static const int signupBonusCoins = 100;

  // Conversion Rate
  static const double coinsPerRupee = 100.0; // 100 coins = ₹1

  // Withdrawal Limits
  static const double minWithdrawalAmount = 50.0; // ₹50
  static const double maxWithdrawalAmount = 10000.0;

  // Task Refresh
  static const int dailyTaskResetHour = 0; // midnight

  // Referral
  static const int referralCodeLength = 8;

  // Pagination
  static const int pageSize = 20;

  // SharedPreferences Keys
  static const String themeKey = 'theme_mode';
  static const String onboardingKey = 'onboarding_done';
  static const String fcmTokenKey = 'fcm_token';
  static const String lastCheckInKey = 'last_check_in';

  // Admin UIDs (add your admin UIDs here)
  static const List<String> adminUIDs = [
    'REPLACE_WITH_ADMIN_UID',
  ];
}

class TaskType {
  static const String daily = 'daily';
  static const String quiz = 'quiz';
  static const String checkIn = 'check_in';
  static const String watchAd = 'watch_ad';
  static const String referral = 'referral';
  static const String special = 'special';
}

class TransactionType {
  static const String earned = 'earned';
  static const String withdrawn = 'withdrawn';
  static const String referralBonus = 'referral_bonus';
  static const String bonus = 'bonus';
  static const String penalty = 'penalty';
}

class WithdrawalStatus {
  static const String pending = 'pending';
  static const String approved = 'approved';
  static const String rejected = 'rejected';
  static const String processing = 'processing';
}

class WithdrawalMethod {
  static const String upi = 'upi';
  static const String amazonGiftCard = 'amazon_gift_card';
  static const String googlePlayGiftCard = 'google_play_gift_card';
  static const String paytm = 'paytm';
}
