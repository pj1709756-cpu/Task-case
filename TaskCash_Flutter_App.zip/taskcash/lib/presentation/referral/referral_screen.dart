// lib/presentation/referral/referral_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../auth/auth_provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../core/widgets/gradient_background.dart';

class ReferralScreen extends StatelessWidget {
  const ReferralScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    final referralCode = user?.referralCode ?? '--------';
    final referralLink =
        'https://taskcash.app/join?ref=$referralCode';

    return GradientBackground(
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              const Text(
                'Refer & Earn',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: Colors.white),
              ).animate().fadeIn(),

              const SizedBox(height: 4),
              Text(
                'Invite friends and earn ${AppConstants.referralCoins} coins per referral',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.5), fontSize: 13),
              ).animate().fadeIn(delay: 100.ms),

              const SizedBox(height: 24),

              // Banner Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1A0533), Color(0xFF0D1117)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                      color: AppColors.secondary.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        gradient: AppColors.purpleGradient,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.secondary.withOpacity(0.4),
                            blurRadius: 20,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: const Icon(Icons.group_add_rounded,
                          color: Colors.white, size: 36),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Your Referral Code',
                      style: TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 10),
                    // Code display
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 24, vertical: 14),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.07),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: AppColors.secondary.withOpacity(0.4)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            referralCode,
                            style: TextStyle(
                              color: AppColors.primary,
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 6,
                              fontFamily: 'monospace',
                            ),
                          ),
                          const SizedBox(width: 14),
                          GestureDetector(
                            onTap: () {
                              Clipboard.setData(
                                  ClipboardData(text: referralCode));
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(const SnackBar(
                                content: Text('Code copied! 📋'),
                                behavior: SnackBarBehavior.floating,
                              ));
                            },
                            child: const Icon(Icons.copy_rounded,
                                color: AppColors.primary, size: 22),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Stats Row
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _ReferralStat(
                          label: 'Referrals',
                          value: '${user?.referralCount ?? 0}',
                          icon: Icons.people_rounded,
                          color: AppColors.secondary,
                        ),
                        Container(
                          width: 1,
                          height: 36,
                          color: Colors.white.withOpacity(0.1),
                          margin:
                              const EdgeInsets.symmetric(horizontal: 20),
                        ),
                        _ReferralStat(
                          label: 'Earned',
                          value:
                              '${user?.referralCoins ?? 0} 🪙',
                          icon: Icons.stars_rounded,
                          color: AppColors.accent,
                        ),
                        Container(
                          width: 1,
                          height: 36,
                          color: Colors.white.withOpacity(0.1),
                          margin:
                              const EdgeInsets.symmetric(horizontal: 20),
                        ),
                        _ReferralStat(
                          label: 'Value',
                          value:
                              '₹${user?.referralEarningsInRupees.toStringAsFixed(0) ?? '0'}',
                          icon: Icons.currency_rupee_rounded,
                          color: AppColors.success,
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Share button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Share.share(
                            '🤑 Join TaskCash and earn money by completing simple tasks!\n\nUse my referral code: *$referralCode*\n\nDownload now: $referralLink\n\nYou\'ll get ${AppConstants.referralBonusCoins} coins FREE when you join!',
                            subject: 'Join TaskCash and earn money!',
                          );
                        },
                        icon: const Icon(Icons.share_rounded,
                            color: Colors.black),
                        label: const Text('Share Referral Link'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.secondary,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () {
                        Clipboard.setData(
                            ClipboardData(text: referralLink));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Link copied! 🔗'),
                            behavior: SnackBarBehavior.floating,
                          ),
                        );
                      },
                      icon: const Icon(Icons.link_rounded,
                          color: AppColors.primary),
                      label: const Text('Copy Link',
                          style: TextStyle(color: AppColors.primary)),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 0),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        side: BorderSide(
                            color: AppColors.primary.withOpacity(0.4)),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ],
                ),
              ).animate().slideY(begin: 0.1, delay: 200.ms),

              const SizedBox(height: 28),

              // How it works
              const Text(
                'How It Works',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 16),

              ..._howItWorks.asMap().entries.map((e) {
                return _HowItWorksStep(
                  step: e.key + 1,
                  title: e.value['title']!,
                  desc: e.value['desc']!,
                  icon: e.value['icon'] as IconData,
                ).animate().slideX(begin: 0.05, delay: (300 + e.key * 80).ms);
              }),

              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
    );
  }

  static final _howItWorks = [
    {
      'title': 'Share your code',
      'desc':
          'Share your unique referral code or link with friends & family',
      'icon': Icons.share_rounded,
    },
    {
      'title': 'Friend signs up',
      'desc':
          'Your friend registers using your referral code',
      'icon': Icons.person_add_rounded,
    },
    {
      'title': 'Both earn coins',
      'desc':
          'You earn ${AppConstants.referralCoins} coins & your friend gets ${AppConstants.referralBonusCoins} bonus coins',
      'icon': Icons.stars_rounded,
    },
    {
      'title': 'Unlimited referrals',
      'desc': 'No limit! Refer more friends and keep earning',
      'icon': Icons.all_inclusive_rounded,
    },
  ];
}

class _ReferralStat extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _ReferralStat({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(height: 4),
        Text(value,
            style: TextStyle(
                color: color,
                fontSize: 15,
                fontWeight: FontWeight.w800)),
        Text(label,
            style: TextStyle(
                color: Colors.white.withOpacity(0.4), fontSize: 11)),
      ],
    );
  }
}

class _HowItWorksStep extends StatelessWidget {
  final int step;
  final String title;
  final String desc;
  final IconData icon;

  const _HowItWorksStep({
    required this.step,
    required this.title,
    required this.desc,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgDarkCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: AppColors.purpleGradient,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text('$step',
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 16)),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(desc,
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 12)),
              ],
            ),
          ),
          Icon(icon,
              color: AppColors.secondary.withOpacity(0.6), size: 20),
        ],
      ),
    );
  }
}
