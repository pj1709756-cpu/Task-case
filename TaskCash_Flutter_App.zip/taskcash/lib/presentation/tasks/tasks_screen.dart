// lib/presentation/tasks/tasks_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../auth/auth_provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../data/models/task_model.dart';
import '../../data/services/task_service.dart';
import '../../core/widgets/gradient_background.dart';
import '../../core/widgets/shimmer_widget.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TaskService _taskService = TaskService();
  Set<String> _completedTaskIds = {};

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadCompletedTasks();
  }

  Future<void> _loadCompletedTasks() async {
    try {
      final completions = await _taskService.getTodayCompletions();
      setState(() {
        _completedTaskIds =
            completions.map((e) => e.taskId).toSet();
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Earn Coins',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        color: Colors.white),
                  ),
                  // Daily check-in button
                  _CheckInButton(onComplete: _loadCompletedTasks),
                ],
              ),
            ).animate().fadeIn(duration: 400.ms),

            const SizedBox(height: 16),

            // Tab Bar
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: AppColors.bgDarkCard,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  gradient: AppColors.primaryGradient,
                  borderRadius: BorderRadius.circular(10),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: Colors.black,
                unselectedLabelColor: AppColors.textMuted,
                labelStyle: const TextStyle(
                    fontSize: 11, fontWeight: FontWeight.w700),
                padding: const EdgeInsets.all(4),
                tabs: const [
                  Tab(text: 'Daily'),
                  Tab(text: 'Quiz'),
                  Tab(text: 'Watch'),
                  Tab(text: 'Special'),
                ],
              ),
            ).animate().slideY(begin: 0.1, delay: 200.ms),

            const SizedBox(height: 16),

            // Tab Views
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _TaskList(
                    type: TaskType.daily,
                    completedIds: _completedTaskIds,
                    onComplete: _loadCompletedTasks,
                  ),
                  _QuizTaskList(
                    completedIds: _completedTaskIds,
                    onComplete: _loadCompletedTasks,
                  ),
                  _WatchAdSection(onComplete: _loadCompletedTasks),
                  _TaskList(
                    type: TaskType.special,
                    completedIds: _completedTaskIds,
                    onComplete: _loadCompletedTasks,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CheckInButton extends StatefulWidget {
  final VoidCallback onComplete;
  const _CheckInButton({required this.onComplete});

  @override
  State<_CheckInButton> createState() => _CheckInButtonState();
}

class _CheckInButtonState extends State<_CheckInButton> {
  final TaskService _taskService = TaskService();
  bool _loading = false;

  Future<void> _checkIn() async {
    setState(() => _loading = true);
    try {
      final coins = await _taskService.dailyCheckIn();
      widget.onComplete();
      if (mounted) {
        _showSuccess(context, '+$coins coins! 🎉 Daily check-in complete!');
      }
    } catch (e) {
      if (mounted) {
        _showError(context, e.toString());
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _loading ? null : _checkIn,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          gradient: AppColors.goldGradient,
          borderRadius: BorderRadius.circular(10),
        ),
        child: _loading
            ? const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.black))
            : const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.calendar_today_rounded,
                      color: Colors.black, size: 14),
                  SizedBox(width: 6),
                  Text('Check In',
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 13,
                          fontWeight: FontWeight.w700)),
                ],
              ),
      ),
    );
  }
}

class _TaskList extends StatelessWidget {
  final String type;
  final Set<String> completedIds;
  final VoidCallback onComplete;

  const _TaskList({
    required this.type,
    required this.completedIds,
    required this.onComplete,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection(AppConstants.tasksCollection)
          .where('type', isEqualTo: type)
          .where('isActive', isEqualTo: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return ListView(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            children: List.generate(
              3,
              (i) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: ShimmerWidget(
                    width: double.infinity, height: 88, borderRadius: 16),
              ),
            ),
          );
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.task_alt_rounded,
                    color: Colors.white.withOpacity(0.2), size: 60),
                const SizedBox(height: 12),
                Text('No tasks available',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.4))),
              ],
            ),
          );
        }

        final tasks = snapshot.data!.docs
            .map((doc) => TaskModel.fromFirestore(doc))
            .toList();

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: tasks.length,
          itemBuilder: (context, i) {
            final task = tasks[i];
            final completed = completedIds.contains(task.id);
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _TaskCard(
                task: task,
                isCompleted: completed,
                onComplete: onComplete,
              ).animate().slideX(begin: 0.05, delay: (i * 80).ms),
            );
          },
        );
      },
    );
  }
}

class _TaskCard extends StatefulWidget {
  final TaskModel task;
  final bool isCompleted;
  final VoidCallback onComplete;

  const _TaskCard({
    required this.task,
    required this.isCompleted,
    required this.onComplete,
  });

  @override
  State<_TaskCard> createState() => _TaskCardState();
}

class _TaskCardState extends State<_TaskCard> {
  bool _loading = false;
  final TaskService _taskService = TaskService();

  Future<void> _complete() async {
    setState(() => _loading = true);
    try {
      final coins = await _taskService.completeTask(widget.task);
      widget.onComplete();
      if (mounted) {
        _showSuccess(context, '+$coins coins earned! 🎉');
      }
    } catch (e) {
      if (mounted) _showError(context, e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final task = widget.task;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: widget.isCompleted
            ? AppColors.success.withOpacity(0.08)
            : AppColors.bgDarkCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: widget.isCompleted
              ? AppColors.success.withOpacity(0.3)
              : Colors.white.withOpacity(0.06),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: _getTaskColor(task.type).withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              _getTaskIcon(task.type),
              color: _getTaskColor(task.type),
              size: 24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  task.title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 3),
                Text(
                  task.description,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.stars_rounded,
                        color: AppColors.accent, size: 14),
                    const SizedBox(width: 4),
                    Text(
                      '+${task.coins} coins',
                      style: const TextStyle(
                          color: AppColors.accent,
                          fontSize: 12,
                          fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          widget.isCompleted
              ? Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.success.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check_rounded,
                          color: AppColors.success, size: 14),
                      SizedBox(width: 4),
                      Text('Done',
                          style: TextStyle(
                              color: AppColors.success,
                              fontSize: 12,
                              fontWeight: FontWeight.w700)),
                    ],
                  ),
                )
              : GestureDetector(
                  onTap: _loading ? null : _complete,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      gradient: AppColors.primaryGradient,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: _loading
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.black))
                        : const Text(
                            'Start',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontWeight: FontWeight.w700),
                          ),
                  ),
                ),
        ],
      ),
    );
  }

  Color _getTaskColor(String type) {
    switch (type) {
      case TaskType.daily:
        return AppColors.primary;
      case TaskType.quiz:
        return AppColors.secondary;
      case TaskType.watchAd:
        return AppColors.warning;
      case TaskType.referral:
        return AppColors.success;
      default:
        return AppColors.info;
    }
  }

  IconData _getTaskIcon(String type) {
    switch (type) {
      case TaskType.daily:
        return Icons.today_rounded;
      case TaskType.quiz:
        return Icons.quiz_rounded;
      case TaskType.watchAd:
        return Icons.play_circle_rounded;
      case TaskType.referral:
        return Icons.people_rounded;
      default:
        return Icons.stars_rounded;
    }
  }
}

class _QuizTaskList extends StatefulWidget {
  final Set<String> completedIds;
  final VoidCallback onComplete;

  const _QuizTaskList({
    required this.completedIds,
    required this.onComplete,
  });

  @override
  State<_QuizTaskList> createState() => _QuizTaskListState();
}

class _QuizTaskListState extends State<_QuizTaskList> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection(AppConstants.tasksCollection)
          .where('type', isEqualTo: TaskType.quiz)
          .where('isActive', isEqualTo: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final tasks = snapshot.data!.docs
            .map((doc) => TaskModel.fromFirestore(doc))
            .toList();

        if (tasks.isEmpty) {
          return Center(
            child: Text('No quizzes available today',
                style: TextStyle(color: Colors.white.withOpacity(0.4))),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: tasks.length,
          itemBuilder: (context, i) {
            final task = tasks[i];
            final completed = widget.completedIds.contains(task.id);
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _QuizCard(
                task: task,
                isCompleted: completed,
                onComplete: widget.onComplete,
              ),
            );
          },
        );
      },
    );
  }
}

class _QuizCard extends StatefulWidget {
  final TaskModel task;
  final bool isCompleted;
  final VoidCallback onComplete;

  const _QuizCard({
    required this.task,
    required this.isCompleted,
    required this.onComplete,
  });

  @override
  State<_QuizCard> createState() => _QuizCardState();
}

class _QuizCardState extends State<_QuizCard> {
  bool _isExpanded = false;
  int? _selectedAnswer;
  bool _loading = false;
  final TaskService _taskService = TaskService();

  Future<void> _submitAnswer() async {
    if (_selectedAnswer == null) return;
    setState(() => _loading = true);

    try {
      final extra = widget.task.extraData;
      final correctAnswer = extra?['correctAnswer'] as int? ?? 0;

      final coins = await _taskService.submitQuizAnswer(
        taskId: widget.task.id,
        selectedAnswer: _selectedAnswer!,
        correctAnswer: correctAnswer,
        coins: widget.task.coins,
      );
      widget.onComplete();
      if (mounted) _showSuccess(context, '+$coins coins! Correct! 🧠');
    } catch (e) {
      if (mounted) _showError(context, e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final extra = widget.task.extraData;
    final options = (extra?['options'] as List?)?.cast<String>() ?? [];

    return Container(
      decoration: BoxDecoration(
        color: AppColors.bgDarkCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: widget.isCompleted
              ? AppColors.success.withOpacity(0.3)
              : Colors.white.withOpacity(0.06),
        ),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: widget.isCompleted
                ? null
                : () => setState(() => _isExpanded = !_isExpanded),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: AppColors.secondary.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.quiz_rounded,
                        color: AppColors.secondary, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          extra?['question'] ?? widget.task.title,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            const Icon(Icons.stars_rounded,
                                color: AppColors.accent, size: 13),
                            const SizedBox(width: 4),
                            Text('+${widget.task.coins} coins',
                                style: const TextStyle(
                                    color: AppColors.accent,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ],
                    ),
                  ),
                  if (widget.isCompleted)
                    const Icon(Icons.check_circle_rounded,
                        color: AppColors.success)
                  else
                    Icon(
                      _isExpanded
                          ? Icons.keyboard_arrow_up_rounded
                          : Icons.keyboard_arrow_down_rounded,
                      color: Colors.white.withOpacity(0.5),
                    ),
                ],
              ),
            ),
          ),
          if (_isExpanded && !widget.isCompleted) ...[
            Divider(color: Colors.white.withOpacity(0.06), height: 1),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  ...List.generate(
                    options.length,
                    (i) => GestureDetector(
                      onTap: () => setState(() => _selectedAnswer = i),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _selectedAnswer == i
                              ? AppColors.secondary.withOpacity(0.2)
                              : AppColors.bgDarkElevated,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: _selectedAnswer == i
                                ? AppColors.secondary
                                : Colors.transparent,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 24,
                              height: 24,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: _selectedAnswer == i
                                      ? AppColors.secondary
                                      : Colors.white.withOpacity(0.3),
                                ),
                                color: _selectedAnswer == i
                                    ? AppColors.secondary
                                    : Colors.transparent,
                              ),
                              child: _selectedAnswer == i
                                  ? const Icon(Icons.check,
                                      color: Colors.white, size: 14)
                                  : null,
                            ),
                            const SizedBox(width: 10),
                            Text(options[i],
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 13)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _selectedAnswer == null || _loading
                          ? null
                          : _submitAnswer,
                      child: _loading
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.black))
                          : const Text('Submit Answer'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _WatchAdSection extends StatefulWidget {
  final VoidCallback onComplete;
  const _WatchAdSection({required this.onComplete});

  @override
  State<_WatchAdSection> createState() => _WatchAdSectionState();
}

class _WatchAdSectionState extends State<_WatchAdSection> {
  bool _loading = false;
  int _adsWatchedToday = 0;
  static const int _maxAdsPerDay = 10;
  final TaskService _taskService = TaskService();

  Future<void> _watchAd() async {
    if (_adsWatchedToday >= _maxAdsPerDay) {
      _showError(context, 'Maximum ads watched for today!');
      return;
    }

    setState(() => _loading = true);

    // Simulate ad watching delay
    await Future.delayed(const Duration(seconds: 3));

    try {
      final coins = await _taskService.watchAd();
      setState(() => _adsWatchedToday++);
      widget.onComplete();
      if (mounted) _showSuccess(context, '+$coins coins! 🎬');
    } catch (e) {
      if (mounted) _showError(context, e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1A1A3E), Color(0xFF0D1117)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                  color: AppColors.warning.withOpacity(0.2)),
            ),
            child: Column(
              children: [
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF6B35), Color(0xFFFF0844)],
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(Icons.play_arrow_rounded,
                      color: Colors.white, size: 44),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Watch & Earn',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                Text(
                  'Watch a short ad and earn ${AppConstants.watchAdCoins} coins instantly!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.5), fontSize: 13),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '$_adsWatchedToday',
                      style: const TextStyle(
                          color: AppColors.warning,
                          fontSize: 28,
                          fontWeight: FontWeight.w900),
                    ),
                    Text(
                      '/$_maxAdsPerDay ads today',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.5),
                          fontSize: 14),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                LinearProgressIndicator(
                  value: _adsWatchedToday / _maxAdsPerDay,
                  backgroundColor: Colors.white.withOpacity(0.1),
                  valueColor:
                      const AlwaysStoppedAnimation(AppColors.warning),
                  borderRadius: BorderRadius.circular(4),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _loading ||
                            _adsWatchedToday >= _maxAdsPerDay
                        ? null
                        : _watchAd,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.warning,
                      foregroundColor: Colors.black,
                    ),
                    child: _loading
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.black),
                              ),
                              const SizedBox(width: 8),
                              const Text('Watching ad...'),
                            ],
                          )
                        : Text(
                            _adsWatchedToday >= _maxAdsPerDay
                                ? '✓ Max reached today'
                                : '▶ Watch Ad (+${AppConstants.watchAdCoins} coins)',
                          ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.bgDarkCard,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline,
                    color: AppColors.info, size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Max $_maxAdsPerDay ads per day. Each ad earns ${AppConstants.watchAdCoins} coins = ₹${(AppConstants.watchAdCoins / 100).toStringAsFixed(2)}',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

void _showSuccess(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(
        children: [
          const Icon(Icons.check_circle_rounded, color: Colors.white),
          const SizedBox(width: 8),
          Text(message),
        ],
      ),
      backgroundColor: AppColors.success,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  );
}

void _showError(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Row(
        children: [
          const Icon(Icons.error_outline, color: Colors.white),
          const SizedBox(width: 8),
          Expanded(child: Text(message)),
        ],
      ),
      backgroundColor: AppColors.error,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  );
}
