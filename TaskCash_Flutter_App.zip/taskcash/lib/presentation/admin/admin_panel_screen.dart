// lib/presentation/admin/admin_panel_screen.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../data/models/transaction_model.dart';
import '../../data/models/user_model.dart';
import '../../data/models/task_model.dart';
import '../../data/services/withdrawal_service.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgDark,
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.admin_panel_settings, color: AppColors.secondary),
            SizedBox(width: 8),
            Text('Admin Panel'),
          ],
        ),
        backgroundColor: AppColors.bgDarkSurface,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.secondary,
          labelColor: AppColors.secondary,
          unselectedLabelColor: AppColors.textMuted,
          labelStyle:
              const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
          tabs: const [
            Tab(text: 'Withdrawals'),
            Tab(text: 'Users'),
            Tab(text: 'Tasks'),
            Tab(text: 'Announce'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [
          _WithdrawalsAdmin(),
          _UsersAdmin(),
          _TasksAdmin(),
          _AnnouncementsAdmin(),
        ],
      ),
    );
  }
}

// ─── Withdrawals Admin ────────────────────────────────────────────────────────

class _WithdrawalsAdmin extends StatefulWidget {
  const _WithdrawalsAdmin();

  @override
  State<_WithdrawalsAdmin> createState() => _WithdrawalsAdminState();
}

class _WithdrawalsAdminState extends State<_WithdrawalsAdmin> {
  final WithdrawalService _service = WithdrawalService();
  String _filter = 'pending';

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Filter chips
        Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ['pending', 'approved', 'rejected', 'all']
                  .map((s) => GestureDetector(
                        onTap: () => setState(() => _filter = s),
                        child: Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: _filter == s
                                ? AppColors.secondary
                                : AppColors.bgDarkCard,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(s.toUpperCase(),
                              style: TextStyle(
                                  color: _filter == s
                                      ? Colors.white
                                      : AppColors.textMuted,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700)),
                        ),
                      ))
                  .toList(),
            ),
          ),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: _filter == 'all'
                ? FirebaseFirestore.instance
                    .collection(AppConstants.withdrawalsCollection)
                    .orderBy('createdAt', descending: true)
                    .snapshots()
                : FirebaseFirestore.instance
                    .collection(AppConstants.withdrawalsCollection)
                    .where('status', isEqualTo: _filter)
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final items = snapshot.data!.docs
                  .map((d) => WithdrawalModel.fromFirestore(d))
                  .toList();

              if (items.isEmpty) {
                return Center(
                    child: Text('No $_filter withdrawals',
                        style: const TextStyle(
                            color: AppColors.textMuted)));
              }

              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: items.length,
                itemBuilder: (_, i) =>
                    _AdminWithdrawalCard(withdrawal: items[i]),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _AdminWithdrawalCard extends StatefulWidget {
  final WithdrawalModel withdrawal;
  const _AdminWithdrawalCard({required this.withdrawal});

  @override
  State<_AdminWithdrawalCard> createState() =>
      _AdminWithdrawalCardState();
}

class _AdminWithdrawalCardState extends State<_AdminWithdrawalCard> {
  final WithdrawalService _service = WithdrawalService();
  bool _loading = false;
  final _txIdController = TextEditingController();
  final _reasonController = TextEditingController();

  @override
  void dispose() {
    _txIdController.dispose();
    _reasonController.dispose();
    super.dispose();
  }

  Future<void> _approve() async {
    final txId = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgDarkCard,
        title: const Text('Approve Withdrawal',
            style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: _txIdController,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(
              labelText: 'Transaction ID (optional)'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () =>
                  Navigator.pop(context, _txIdController.text),
              child: const Text('Approve')),
        ],
      ),
    );
    if (txId == null) return;

    setState(() => _loading = true);
    try {
      await _service.approveWithdrawal(widget.withdrawal.id, txId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Withdrawal approved ✅'),
          backgroundColor: AppColors.success,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _reject() async {
    final reason = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.bgDarkCard,
        title: const Text('Reject Withdrawal',
            style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: _reasonController,
          style: const TextStyle(color: Colors.white),
          decoration:
              const InputDecoration(labelText: 'Rejection reason'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.error),
              onPressed: () =>
                  Navigator.pop(context, _reasonController.text),
              child: const Text('Reject')),
        ],
      ),
    );
    if (reason == null) return;

    setState(() => _loading = true);
    try {
      await _service.rejectWithdrawal(widget.withdrawal.id, reason,
          widget.withdrawal.userId, widget.withdrawal.coins);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Withdrawal rejected'),
          backgroundColor: AppColors.error,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.withdrawal;
    final isPending = w.status == WithdrawalStatus.pending;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgDarkCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(w.userName,
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w700)),
                Text(w.userEmail,
                    style: const TextStyle(
                        color: AppColors.textMuted, fontSize: 12)),
              ]),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('₹${w.amount.toStringAsFixed(2)}',
                    style: const TextStyle(
                        color: AppColors.primary,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
                Text('${w.coins} coins',
                    style: const TextStyle(
                        color: AppColors.textMuted, fontSize: 11)),
              ]),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.info.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(_getMethodName(w.method),
                    style: const TextStyle(
                        color: AppColors.info,
                        fontSize: 11,
                        fontWeight: FontWeight.w600)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(w.accountDetails,
                    style: const TextStyle(
                        color: AppColors.textMuted, fontSize: 12),
                    overflow: TextOverflow.ellipsis),
              ),
            ],
          ),
          if (isPending) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _loading ? null : _reject,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.error),
                      foregroundColor: AppColors.error,
                    ),
                    child: const Text('Reject'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _loading ? null : _approve,
                    child: _loading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.black))
                        : const Text('Approve'),
                  ),
                ),
              ],
            ),
          ] else ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _statusColor(w.status).withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(w.status.toUpperCase(),
                  style: TextStyle(
                      color: _statusColor(w.status),
                      fontSize: 11,
                      fontWeight: FontWeight.w700)),
            ),
          ],
        ],
      ),
    );
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'approved':
        return AppColors.success;
      case 'rejected':
        return AppColors.error;
      default:
        return AppColors.warning;
    }
  }

  String _getMethodName(String m) {
    switch (m) {
      case 'upi':
        return 'UPI';
      case 'amazon_gift_card':
        return 'Amazon GC';
      case 'google_play_gift_card':
        return 'Play GC';
      default:
        return m;
    }
  }
}

// ─── Users Admin ──────────────────────────────────────────────────────────────

class _UsersAdmin extends StatelessWidget {
  const _UsersAdmin();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection(AppConstants.usersCollection)
          .orderBy('createdAt', descending: true)
          .limit(100)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final users = snapshot.data!.docs
            .map((d) => UserModel.fromFirestore(d))
            .toList();

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.people_rounded,
                      color: AppColors.primary, size: 18),
                  const SizedBox(width: 8),
                  Text('${users.length} total users',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: users.length,
                itemBuilder: (_, i) => _AdminUserTile(user: users[i]),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _AdminUserTile extends StatelessWidget {
  final UserModel user;
  const _AdminUserTile({required this.user});

  Future<void> _toggleBlock(BuildContext context) async {
    await FirebaseFirestore.instance
        .collection(AppConstants.usersCollection)
        .doc(user.uid)
        .update({'isActive': !user.isActive});
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(user.isActive
              ? 'User blocked'
              : 'User unblocked'),
          backgroundColor:
              user.isActive ? AppColors.error : AppColors.success,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgDarkCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: user.isActive
              ? Colors.white.withOpacity(0.05)
              : AppColors.error.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: AppColors.primary.withOpacity(0.2),
            backgroundImage: user.photoUrl != null
                ? NetworkImage(user.photoUrl!)
                : null,
            child: user.photoUrl == null
                ? Text(
                    user.name.isNotEmpty
                        ? user.name[0].toUpperCase()
                        : 'U',
                    style: const TextStyle(color: AppColors.primary),
                  )
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(user.name,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 13)),
                    if (user.isAdmin) ...[
                      const SizedBox(width: 6),
                      const Icon(Icons.admin_panel_settings,
                          color: AppColors.secondary, size: 13),
                    ],
                  ],
                ),
                Text(user.email,
                    style: const TextStyle(
                        color: AppColors.textMuted, fontSize: 11)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('${user.totalCoins} 🪙',
                  style: const TextStyle(
                      color: AppColors.accent,
                      fontSize: 12,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              GestureDetector(
                onTap: () => _toggleBlock(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: user.isActive
                        ? AppColors.error.withOpacity(0.1)
                        : AppColors.success.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    user.isActive ? 'Block' : 'Unblock',
                    style: TextStyle(
                        color: user.isActive
                            ? AppColors.error
                            : AppColors.success,
                        fontSize: 10,
                        fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── Tasks Admin ──────────────────────────────────────────────────────────────

class _TasksAdmin extends StatefulWidget {
  const _TasksAdmin();

  @override
  State<_TasksAdmin> createState() => _TasksAdminState();
}

class _TasksAdminState extends State<_TasksAdmin> {
  void _showAddTaskDialog() {
    final titleCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final coinsCtrl = TextEditingController(text: '50');
    String type = TaskType.daily;

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          backgroundColor: AppColors.bgDarkCard,
          title: const Text('Add Task',
              style: TextStyle(color: Colors.white)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(labelText: 'Title'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: descCtrl,
                  style: const TextStyle(color: Colors.white),
                  decoration:
                      const InputDecoration(labelText: 'Description'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: coinsCtrl,
                  style: const TextStyle(color: Colors.white),
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: 'Coins'),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: type,
                  dropdownColor: AppColors.bgDarkCard,
                  style: const TextStyle(color: Colors.white),
                  decoration:
                      const InputDecoration(labelText: 'Type'),
                  items: [
                    TaskType.daily,
                    TaskType.quiz,
                    TaskType.special
                  ]
                      .map((t) => DropdownMenuItem(
                          value: t,
                          child: Text(t.toUpperCase())))
                      .toList(),
                  onChanged: (v) => setState(() => type = v!),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                if (titleCtrl.text.isEmpty) return;
                await FirebaseFirestore.instance
                    .collection(AppConstants.tasksCollection)
                    .add({
                  'title': titleCtrl.text.trim(),
                  'description': descCtrl.text.trim(),
                  'type': type,
                  'coins': int.tryParse(coinsCtrl.text) ?? 50,
                  'isActive': true,
                  'completionCount': 0,
                  'createdAt': FieldValue.serverTimestamp(),
                  'difficulty': 1,
                });
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _showAddTaskDialog,
              icon: const Icon(Icons.add_rounded, color: Colors.black),
              label: const Text('Add New Task'),
            ),
          ),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection(AppConstants.tasksCollection)
                .orderBy('createdAt', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final tasks = snapshot.data!.docs
                  .map((d) => TaskModel.fromFirestore(d))
                  .toList();

              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: tasks.length,
                itemBuilder: (_, i) {
                  final t = tasks[i];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.bgDarkCard,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(t.title,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700)),
                              Text('${t.type} • ${t.coins} coins',
                                  style: const TextStyle(
                                      color: AppColors.textMuted,
                                      fontSize: 12)),
                              Text(
                                  '${t.completionCount} completions',
                                  style: const TextStyle(
                                      color: AppColors.primary,
                                      fontSize: 11)),
                            ],
                          ),
                        ),
                        Switch(
                          value: t.isActive,
                          activeColor: AppColors.primary,
                          onChanged: (val) {
                            FirebaseFirestore.instance
                                .collection(AppConstants.tasksCollection)
                                .doc(t.id)
                                .update({'isActive': val});
                          },
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

// ─── Announcements Admin ──────────────────────────────────────────────────────

class _AnnouncementsAdmin extends StatefulWidget {
  const _AnnouncementsAdmin();

  @override
  State<_AnnouncementsAdmin> createState() =>
      _AnnouncementsAdminState();
}

class _AnnouncementsAdminState extends State<_AnnouncementsAdmin> {
  final _titleCtrl = TextEditingController();
  final _bodyCtrl = TextEditingController();
  bool _loading = false;

  @override
  void dispose() {
    _titleCtrl.dispose();
    _bodyCtrl.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_titleCtrl.text.isEmpty || _bodyCtrl.text.isEmpty) return;
    setState(() => _loading = true);
    try {
      await FirebaseFirestore.instance
          .collection(AppConstants.announcementsCollection)
          .add({
        'title': _titleCtrl.text.trim(),
        'body': _bodyCtrl.text.trim(),
        'createdAt': FieldValue.serverTimestamp(),
        'isActive': true,
      });
      _titleCtrl.clear();
      _bodyCtrl.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Announcement sent! 📢'),
          backgroundColor: AppColors.success,
        ));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Send Announcement',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          TextField(
            controller: _titleCtrl,
            style: const TextStyle(color: Colors.white),
            decoration: const InputDecoration(
                labelText: 'Title', hintText: 'Announcement title'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _bodyCtrl,
            style: const TextStyle(color: Colors.white),
            maxLines: 4,
            decoration: const InputDecoration(
                labelText: 'Message', hintText: 'Enter your message'),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loading ? null : _send,
              icon: const Icon(Icons.send_rounded, color: Colors.black),
              label: _loading
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.black))
                  : const Text('Send to All Users'),
            ),
          ),
          const SizedBox(height: 28),
          const Text('Past Announcements',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection(AppConstants.announcementsCollection)
                .orderBy('createdAt', descending: true)
                .limit(20)
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final items = snapshot.data!.docs;
              return Column(
                children: items.map((doc) {
                  final d = doc.data() as Map<String, dynamic>;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.bgDarkCard,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(d['title'] ?? '',
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text(d['body'] ?? '',
                            style: const TextStyle(
                                color: AppColors.textMuted,
                                fontSize: 13)),
                      ],
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}
