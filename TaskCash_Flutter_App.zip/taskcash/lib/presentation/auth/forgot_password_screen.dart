// lib/presentation/auth/forgot_password_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'auth_provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/custom_button.dart';
import '../../core/widgets/custom_text_field.dart';
import '../../core/widgets/gradient_background.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  bool _emailSent = false;

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _sendReset() async {
    if (!_formKey.currentState!.validate()) return;

    final auth = context.read<AuthProvider>();
    final success =
        await auth.sendPasswordResetEmail(_emailController.text.trim());
    if (success && mounted) {
      setState(() => _emailSent = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back_ios_new,
                      color: Colors.white),
                  padding: EdgeInsets.zero,
                ),
                const SizedBox(height: 40),

                if (!_emailSent) ...[
                  const Icon(Icons.lock_reset,
                      color: AppColors.primary, size: 56)
                      .animate()
                      .scale(duration: 400.ms),
                  const SizedBox(height: 24),
                  const Text(
                    'Reset Password',
                    style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: Colors.white),
                  ).animate().slideX(begin: -0.1),
                  const SizedBox(height: 8),
                  Text(
                    'Enter your email and we\'ll send you a reset link',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.5), fontSize: 14),
                  ).animate().fadeIn(delay: 200.ms),
                  const SizedBox(height: 40),
                  Form(
                    key: _formKey,
                    child: CustomTextField(
                      controller: _emailController,
                      label: 'Email Address',
                      hint: 'you@example.com',
                      prefixIcon: Icons.email_outlined,
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) {
                        if (v == null || v.isEmpty) return 'Enter your email';
                        if (!v.contains('@')) return 'Enter a valid email';
                        return null;
                      },
                    ),
                  ).animate().slideY(begin: 0.1, delay: 300.ms),
                  const SizedBox(height: 24),
                  Consumer<AuthProvider>(
                    builder: (context, auth, _) {
                      if (auth.errorMessage != null) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: Text(auth.errorMessage!,
                              style:
                                  const TextStyle(color: AppColors.error)),
                        );
                      }
                      return const SizedBox.shrink();
                    },
                  ),
                  Consumer<AuthProvider>(
                    builder: (context, auth, _) {
                      return CustomButton(
                        text: 'Send Reset Link',
                        isLoading: auth.isLoading,
                        onPressed: _sendReset,
                        gradient: AppColors.primaryGradient,
                      );
                    },
                  ).animate().slideY(begin: 0.1, delay: 400.ms),
                ] else ...[
                  const Icon(Icons.mark_email_read_outlined,
                      color: AppColors.success, size: 80)
                      .animate()
                      .scale(duration: 400.ms)
                      .then()
                      .shake(hz: 2),
                  const SizedBox(height: 24),
                  const Text(
                    'Email Sent!',
                    style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: Colors.white),
                  ).animate().fadeIn(),
                  const SizedBox(height: 12),
                  Text(
                    'Check your inbox at ${_emailController.text} for password reset instructions.',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.5), fontSize: 14,
                        height: 1.6),
                  ).animate().fadeIn(delay: 200.ms),
                  const SizedBox(height: 40),
                  CustomButton(
                    text: 'Back to Sign In',
                    onPressed: () => Navigator.pop(context),
                    gradient: AppColors.primaryGradient,
                  ).animate().slideY(begin: 0.1, delay: 300.ms),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
