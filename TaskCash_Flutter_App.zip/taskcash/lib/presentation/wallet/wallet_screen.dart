// lib/presentation/wallet/wallet_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../auth/auth_provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../data/models/transaction_model.dart';
import '../../data/services/withdrawal_service.dart';
import '../../core/widgets/gradient_background.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.user;

    return GradientBackground(
      child: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'My Wallet',
                    style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        color: Colors.white),
                  ),
                  GestureDetector(
                    onTap: () => _showWithdrawalSheet(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        gradient: AppColors.primaryGradient,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_circle_up_rounded,
                              color: Colors.black, size: 16),
                          SizedBox(width: 6),
                          Text('Withdraw',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ).animate().fadeIn(),

            const SizedBox(height: 20),

            // Balance Cards
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Expanded(
                    child: _WalletCard(
                      title: 'Available',
                      value:
                          '₹${user?.balanceInRupees.toStringAsFixed(2) ?? '0.00'}',
                      subtitle:
                          '${user?.totalCoins ?? 0} coins',
                      color: AppColors.primary,
                      icon: Icons.account_balance_wallet_rounded,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _WalletCard(
                      title: 'Total Earned',
                      value:
                          '₹${user?.totalEarningsInRupees.toStringAsFixed(2) ?? '0.00'}',
                      subtitle: 'All time',
                      color: AppColors.secondary,
                      icon: Icons.trending_up_rounded,
                    ),
                  ),
                ],
              ),
            ).animate().slideY(begin: 0.1, delay: 150.ms),

            const SizedBox(height: 20),

            // Tabs
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: AppColors.bgDarkCard,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TabBar(
                controller: _tabController,
                indicator: BoxDecoration(
                  gradient: AppColors.primaryGradient,
                  borderRadius: BorderRadius.circular(10),
                ),
                indicatorSize: TabBarIndicatorSize.tab,
                dividerColor: Colors.transparent,
                labelColor: Colors.black,
                unselectedLabelColor: AppColors.textMuted,
                labelStyle: const TextStyle(fontWeight: FontWeight.w700),
                padding: const EdgeInsets.all(4),
                tabs: const [
                  Tab(text: 'Transactions'),
                  Tab(text: 'Withdrawals'),
                ],
              ),
            ).animate().slideY(begin: 0.1, delay: 200.ms),

            const SizedBox(height: 16),

            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  user != null
                      ? _TransactionsTab(userId: user.uid)
                      : const Center(child: CircularProgressIndicator()),
                  user != null
                      ? _WithdrawalsTab(userId: user.uid)
                      : const Center(child: CircularProgressIndicator()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showWithdrawalSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const WithdrawalSheet(),
    );
  }
}

class _WalletCard extends StatelessWidget {
  final String title;
  final String value;
  final String subtitle;
  final Color color;
  final IconData icon;

  const _WalletCard({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.5), fontSize: 12)),
              Icon(icon, color: color, size: 18),
            ],
          ),
          const SizedBox(height: 8),
          Text(value,
              style: TextStyle(
                  color: color,
                  fontSize: 20,
                  fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(subtitle,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.4), fontSize: 11)),
        ],
      ),
    );
  }
}

class _TransactionsTab extends StatelessWidget {
  final String userId;
  const _TransactionsTab({required this.userId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection(AppConstants.transactionsCollection)
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .limit(50)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final transactions = snapshot.data!.docs
            .map((doc) => TransactionModel.fromFirestore(doc))
            .toList();

        if (transactions.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.receipt_long_rounded,
                    color: Colors.white.withOpacity(0.2), size: 60),
                const SizedBox(height: 12),
                Text('No transactions yet',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.4))),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: transactions.length,
          itemBuilder: (context, i) {
            final tx = transactions[i];
            final formatter = DateFormat('MMM d, h:mm a');
            final isCredit = tx.coins > 0;
            final color =
                isCredit ? AppColors.success : AppColors.error;
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.bgDarkCard,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      isCredit
                          ? Icons.add_circle_outline_rounded
                          : Icons.remove_circle_outline_rounded,
                      color: color,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tx.description,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 2),
                        Text(formatter.format(tx.createdAt),
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.4),
                                fontSize: 11)),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '${isCredit ? '+' : ''}${tx.coins} 🪙',
                        style: TextStyle(
                            color: color,
                            fontSize: 13,
                            fontWeight: FontWeight.w700),
                      ),
                      Text(
                        '${isCredit ? '+' : ''}₹${(tx.coins.abs() / 100).toStringAsFixed(2)}',
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 11),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _WithdrawalsTab extends StatelessWidget {
  final String userId;
  const _WithdrawalsTab({required this.userId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection(AppConstants.withdrawalsCollection)
          .where('userId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final withdrawals = snapshot.data!.docs
            .map((doc) => WithdrawalModel.fromFirestore(doc))
            .toList();

        if (withdrawals.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.savings_rounded,
                    color: Colors.white.withOpacity(0.2), size: 60),
                const SizedBox(height: 12),
                Text('No withdrawal requests',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.4))),
                const SizedBox(height: 8),
                Text(
                  'Minimum withdrawal: ₹${AppConstants.minWithdrawalAmount}',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.3), fontSize: 12),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          itemCount: withdrawals.length,
          itemBuilder: (context, i) {
            final w = withdrawals[i];
            return _WithdrawalTile(withdrawal: w);
          },
        );
      },
    );
  }
}

class _WithdrawalTile extends StatelessWidget {
  final WithdrawalModel withdrawal;
  const _WithdrawalTile({required this.withdrawal});

  @override
  Widget build(BuildContext context) {
    final statusColor = _getStatusColor(withdrawal.status);
    final formatter = DateFormat('MMM d, yyyy');

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgDarkCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: statusColor.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '₹${withdrawal.amount.toStringAsFixed(2)}',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  withdrawal.status.toUpperCase(),
                  style: TextStyle(
                      color: statusColor,
                      fontSize: 10,
                      fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.payment_rounded,
                  color: Colors.white.withOpacity(0.4), size: 14),
              const SizedBox(width: 6),
              Text(
                _getMethodName(withdrawal.method),
                style: TextStyle(
                    color: Colors.white.withOpacity(0.5), fontSize: 12),
              ),
              const Spacer(),
              Text(
                formatter.format(withdrawal.createdAt),
                style: TextStyle(
                    color: Colors.white.withOpacity(0.4), fontSize: 12),
              ),
            ],
          ),
          if (withdrawal.rejectionReason != null) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.error.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'Reason: ${withdrawal.rejectionReason}',
                style: const TextStyle(
                    color: AppColors.error, fontSize: 12),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case WithdrawalStatus.approved:
        return AppColors.success;
      case WithdrawalStatus.rejected:
        return AppColors.error;
      case WithdrawalStatus.processing:
        return AppColors.info;
      default:
        return AppColors.warning;
    }
  }

  String _getMethodName(String method) {
    switch (method) {
      case WithdrawalMethod.upi:
        return 'UPI Transfer';
      case WithdrawalMethod.amazonGiftCard:
        return 'Amazon Gift Card';
      case WithdrawalMethod.googlePlayGiftCard:
        return 'Google Play Gift Card';
      default:
        return method;
    }
  }
}

class WithdrawalSheet extends StatefulWidget {
  const WithdrawalSheet({super.key});

  @override
  State<WithdrawalSheet> createState() => _WithdrawalSheetState();
}

class _WithdrawalSheetState extends State<WithdrawalSheet> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _accountController = TextEditingController();
  String _selectedMethod = WithdrawalMethod.upi;
  bool _loading = false;
  final WithdrawalService _withdrawalService = WithdrawalService();

  @override
  void dispose() {
    _amountController.dispose();
    _accountController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final user = context.read<AuthProvider>().user;
    if (user == null) return;

    setState(() => _loading = true);
    try {
      await _withdrawalService.requestWithdrawal(
        user: user,
        amount: double.parse(_amountController.text),
        method: _selectedMethod,
        accountDetails: _accountController.text.trim(),
      );
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Withdrawal request submitted! ✅'),
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e.toString()),
            backgroundColor: AppColors.error,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: const BoxDecoration(
        color: AppColors.bgDarkSurface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Withdraw Funds',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w800),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'Available: ₹${user?.balanceInRupees.toStringAsFixed(2) ?? '0.00'} (${user?.totalCoins ?? 0} coins)',
                style: TextStyle(
                    color: AppColors.primary, fontSize: 13),
              ),
              const SizedBox(height: 20),

              // Method selection
              const Text('Withdrawal Method',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 14)),
              const SizedBox(height: 10),
              Row(
                children: [
                  _MethodChip(
                    label: 'UPI',
                    icon: Icons.currency_rupee,
                    method: WithdrawalMethod.upi,
                    selectedMethod: _selectedMethod,
                    onTap: () =>
                        setState(() => _selectedMethod = WithdrawalMethod.upi),
                  ),
                  const SizedBox(width: 8),
                  _MethodChip(
                    label: 'Amazon',
                    icon: Icons.shopping_bag_outlined,
                    method: WithdrawalMethod.amazonGiftCard,
                    selectedMethod: _selectedMethod,
                    onTap: () => setState(
                        () => _selectedMethod = WithdrawalMethod.amazonGiftCard),
                  ),
                  const SizedBox(width: 8),
                  _MethodChip(
                    label: 'Play',
                    icon: Icons.games_outlined,
                    method: WithdrawalMethod.googlePlayGiftCard,
                    selectedMethod: _selectedMethod,
                    onTap: () => setState(() =>
                        _selectedMethod = WithdrawalMethod.googlePlayGiftCard),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // Amount
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Amount (₹)',
                  hintText: 'Min ₹${AppConstants.minWithdrawalAmount}',
                  prefixText: '₹ ',
                  prefixStyle: const TextStyle(color: AppColors.primary),
                ),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Enter amount';
                  final amount = double.tryParse(v);
                  if (amount == null) return 'Invalid amount';
                  if (amount < AppConstants.minWithdrawalAmount)
                    return 'Min ₹${AppConstants.minWithdrawalAmount}';
                  if (amount > (user?.balanceInRupees ?? 0))
                    return 'Insufficient balance';
                  return null;
                },
              ),

              const SizedBox(height: 12),

              // Account details
              TextFormField(
                controller: _accountController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: _selectedMethod == WithdrawalMethod.upi
                      ? 'UPI ID'
                      : 'Email for Gift Card',
                  hintText: _selectedMethod == WithdrawalMethod.upi
                      ? 'yourname@upi'
                      : 'you@example.com',
                ),
                validator: (v) =>
                    v == null || v.isEmpty ? 'This field is required' : null,
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _loading ? null : _submit,
                  child: _loading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.black))
                      : const Text('Submit Request'),
                ),
              ),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  'Processing time: 1-3 business days',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.3), fontSize: 11),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MethodChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final String method;
  final String selectedMethod;
  final VoidCallback onTap;

  const _MethodChip({
    required this.label,
    required this.icon,
    required this.method,
    required this.selectedMethod,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = method == selectedMethod;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? AppColors.primary.withOpacity(0.2)
              : AppColors.bgDarkCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected
                ? AppColors.primary
                : Colors.white.withOpacity(0.1),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon,
                color: isSelected ? AppColors.primary : AppColors.textMuted,
                size: 16),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                    color: isSelected
                        ? AppColors.primary
                        : AppColors.textMuted,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}
