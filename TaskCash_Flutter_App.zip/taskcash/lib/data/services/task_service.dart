// lib/data/services/task_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/task_model.dart';
import '../models/transaction_model.dart';
import '../../core/constants/app_constants.dart';

class TaskService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String get _uid => _auth.currentUser!.uid;

  // Get all active tasks
  Stream<List<TaskModel>> getActiveTasks({String? type}) {
    Query query = _firestore
        .collection(AppConstants.tasksCollection)
        .where('isActive', isEqualTo: true);

    if (type != null) {
      query = query.where('type', isEqualTo: type);
    }

    return query.snapshots().map((snap) =>
        snap.docs.map((doc) => TaskModel.fromFirestore(doc)).toList());
  }

  // Get user task completions for today
  Future<List<UserTaskModel>> getTodayCompletions() async {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);

    final snap = await _firestore
        .collection(AppConstants.userTasksCollection)
        .where('userId', isEqualTo: _uid)
        .where('completedAt',
            isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .get();

    return snap.docs.map((doc) => UserTaskModel.fromFirestore(doc)).toList();
  }

  // Check if user already completed a task today
  Future<bool> hasCompletedTaskToday(String taskId) async {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);

    final snap = await _firestore
        .collection(AppConstants.userTasksCollection)
        .where('userId', isEqualTo: _uid)
        .where('taskId', isEqualTo: taskId)
        .where('completedAt',
            isGreaterThanOrEqualTo: Timestamp.fromDate(startOfDay))
        .get();

    return snap.docs.isNotEmpty;
  }

  // Complete a task
  Future<int> completeTask(TaskModel task) async {
    final alreadyDone = await hasCompletedTaskToday(task.id);
    if (alreadyDone) throw 'Task already completed today!';

    final batch = _firestore.batch();

    // Add user task record
    final userTaskRef =
        _firestore.collection(AppConstants.userTasksCollection).doc();
    batch.set(userTaskRef, {
      'userId': _uid,
      'taskId': task.id,
      'isCompleted': true,
      'completedAt': FieldValue.serverTimestamp(),
      'coinsEarned': task.coins,
    });

    // Update user coins
    final userRef =
        _firestore.collection(AppConstants.usersCollection).doc(_uid);
    batch.update(userRef, {
      'totalCoins': FieldValue.increment(task.coins),
      'todayCoins': FieldValue.increment(task.coins),
      'totalEarnings': FieldValue.increment(task.coins),
    });

    // Update task completion count
    final taskRef =
        _firestore.collection(AppConstants.tasksCollection).doc(task.id);
    batch.update(taskRef, {
      'completionCount': FieldValue.increment(1),
    });

    // Add transaction
    final txRef =
        _firestore.collection(AppConstants.transactionsCollection).doc();
    batch.set(txRef, {
      'userId': _uid,
      'type': TransactionType.earned,
      'coins': task.coins,
      'description': 'Completed: ${task.title}',
      'createdAt': FieldValue.serverTimestamp(),
      'taskId': task.id,
    });

    await batch.commit();
    return task.coins;
  }

  // Daily Check-In
  Future<int> dailyCheckIn() async {
    final userRef =
        _firestore.collection(AppConstants.usersCollection).doc(_uid);
    final userDoc = await userRef.get();
    final data = userDoc.data() as Map<String, dynamic>;

    final lastCheckIn = (data['lastCheckIn'] as Timestamp?)?.toDate();
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    if (lastCheckIn != null) {
      final lastCheckInDay = DateTime(
          lastCheckIn.year, lastCheckIn.month, lastCheckIn.day);
      if (lastCheckInDay == today) {
        throw 'Already checked in today!';
      }
    }

    final int currentStreak = (data['streak'] ?? 0).toInt();
    int bonusCoins = AppConstants.checkInCoins;

    // Streak bonus
    if (currentStreak >= 6) bonusCoins += 50;
    else if (currentStreak >= 3) bonusCoins += 20;
    else if (currentStreak >= 1) bonusCoins += 10;

    final batch = _firestore.batch();
    batch.update(userRef, {
      'totalCoins': FieldValue.increment(bonusCoins),
      'todayCoins': FieldValue.increment(bonusCoins),
      'totalEarnings': FieldValue.increment(bonusCoins),
      'lastCheckIn': FieldValue.serverTimestamp(),
      'streak': FieldValue.increment(1),
    });

    final txRef =
        _firestore.collection(AppConstants.transactionsCollection).doc();
    batch.set(txRef, {
      'userId': _uid,
      'type': TransactionType.earned,
      'coins': bonusCoins,
      'description': 'Daily check-in bonus 📅 (${currentStreak + 1} day streak)',
      'createdAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();
    return bonusCoins;
  }

  // Watch Ad (simulated)
  Future<int> watchAd() async {
    // In production, integrate with AdMob and verify ad completion server-side
    const coins = AppConstants.watchAdCoins;

    final batch = _firestore.batch();

    final userRef =
        _firestore.collection(AppConstants.usersCollection).doc(_uid);
    batch.update(userRef, {
      'totalCoins': FieldValue.increment(coins),
      'todayCoins': FieldValue.increment(coins),
      'totalEarnings': FieldValue.increment(coins),
    });

    final txRef =
        _firestore.collection(AppConstants.transactionsCollection).doc();
    batch.set(txRef, {
      'userId': _uid,
      'type': TransactionType.earned,
      'coins': coins,
      'description': 'Watched ad reward 📺',
      'createdAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();
    return coins;
  }

  // Submit Quiz Answer
  Future<int> submitQuizAnswer({
    required String taskId,
    required int selectedAnswer,
    required int correctAnswer,
    required int coins,
  }) async {
    if (selectedAnswer != correctAnswer) {
      throw 'Incorrect answer! Try again tomorrow.';
    }

    final alreadyDone = await hasCompletedTaskToday(taskId);
    if (alreadyDone) throw 'Quiz already completed today!';

    final batch = _firestore.batch();

    final userTaskRef =
        _firestore.collection(AppConstants.userTasksCollection).doc();
    batch.set(userTaskRef, {
      'userId': _uid,
      'taskId': taskId,
      'isCompleted': true,
      'completedAt': FieldValue.serverTimestamp(),
      'coinsEarned': coins,
    });

    final userRef =
        _firestore.collection(AppConstants.usersCollection).doc(_uid);
    batch.update(userRef, {
      'totalCoins': FieldValue.increment(coins),
      'todayCoins': FieldValue.increment(coins),
      'totalEarnings': FieldValue.increment(coins),
    });

    final txRef =
        _firestore.collection(AppConstants.transactionsCollection).doc();
    batch.set(txRef, {
      'userId': _uid,
      'type': TransactionType.earned,
      'coins': coins,
      'description': 'Quiz completed! 🧠',
      'createdAt': FieldValue.serverTimestamp(),
      'taskId': taskId,
    });

    await batch.commit();
    return coins;
  }

  // Get transactions
  Stream<List<TransactionModel>> getTransactions({int limit = 20}) {
    return _firestore
        .collection(AppConstants.transactionsCollection)
        .where('userId', isEqualTo: _uid)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) =>
            snap.docs.map((doc) => TransactionModel.fromFirestore(doc)).toList());
  }
}
