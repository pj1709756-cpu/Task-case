// lib/data/services/auth_service.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../models/user_model.dart';
import '../../core/constants/app_constants.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final Uuid _uuid = const Uuid();

  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Generate unique referral code
  String _generateReferralCode(String uid) {
    return uid.substring(0, AppConstants.referralCodeLength).toUpperCase();
  }

  // Create user document in Firestore
  Future<UserModel> _createUserDocument(
    User user, {
    String? displayName,
    String? referralCode,
  }) async {
    final referralCodeForUser = _generateReferralCode(user.uid);

    final userModel = UserModel(
      uid: user.uid,
      email: user.email ?? '',
      name: displayName ?? user.displayName ?? 'User',
      photoUrl: user.photoURL,
      referralCode: referralCodeForUser,
      referredBy: referralCode,
      totalCoins: AppConstants.signupBonusCoins,
      createdAt: DateTime.now(),
      lastSeen: DateTime.now(),
    );

    await _firestore
        .collection(AppConstants.usersCollection)
        .doc(user.uid)
        .set(userModel.toFirestore());

    // Process referral if any
    if (referralCode != null) {
      await _processReferral(user.uid, referralCode);
    }

    // Add signup bonus transaction
    await _addTransaction(
      userId: user.uid,
      type: TransactionType.bonus,
      coins: AppConstants.signupBonusCoins,
      description: 'Welcome bonus! 🎉',
    );

    return userModel;
  }

  Future<void> _processReferral(String newUserId, String referralCode) async {
    try {
      final query = await _firestore
          .collection(AppConstants.usersCollection)
          .where('referralCode', isEqualTo: referralCode)
          .limit(1)
          .get();

      if (query.docs.isNotEmpty) {
        final referrerDoc = query.docs.first;
        final referrerId = referrerDoc.id;

        // Add coins to referrer
        await _firestore
            .collection(AppConstants.usersCollection)
            .doc(referrerId)
            .update({
          'totalCoins': FieldValue.increment(AppConstants.referralCoins),
          'referralCoins': FieldValue.increment(AppConstants.referralCoins),
          'referralCount': FieldValue.increment(1),
        });

        // Add referral bonus to new user
        await _firestore
            .collection(AppConstants.usersCollection)
            .doc(newUserId)
            .update({
          'totalCoins': FieldValue.increment(AppConstants.referralBonusCoins),
        });

        // Log referral transaction for referrer
        await _addTransaction(
          userId: referrerId,
          type: TransactionType.referralBonus,
          coins: AppConstants.referralCoins,
          description: 'Referral bonus earned! 🎯',
          referralUserId: newUserId,
        );

        // Log referral bonus for new user
        await _addTransaction(
          userId: newUserId,
          type: TransactionType.referralBonus,
          coins: AppConstants.referralBonusCoins,
          description: 'Referral welcome bonus! 🎁',
        );
      }
    } catch (e) {
      print('Error processing referral: $e');
    }
  }

  Future<void> _addTransaction({
    required String userId,
    required String type,
    required int coins,
    required String description,
    String? taskId,
    String? referralUserId,
  }) async {
    await _firestore.collection(AppConstants.transactionsCollection).add({
      'userId': userId,
      'type': type,
      'coins': coins,
      'description': description,
      'createdAt': FieldValue.serverTimestamp(),
      'taskId': taskId,
      'referralUserId': referralUserId,
    });
  }

  // Sign up with email/password
  Future<UserModel?> signUpWithEmail({
    required String email,
    required String password,
    required String name,
    String? referralCode,
  }) async {
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      await credential.user!.updateDisplayName(name);
      await credential.user!.sendEmailVerification();

      return await _createUserDocument(
        credential.user!,
        displayName: name,
        referralCode: referralCode,
      );
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    }
  }

  // Sign in with email/password
  Future<UserModel?> signInWithEmail({
    required String email,
    required String password,
  }) async {
    try {
      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      return await _getOrCreateUserDoc(credential.user!);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    }
  }

  // Google Sign-In
  Future<UserModel?> signInWithGoogle({String? referralCode}) async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) return null;

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await _auth.signInWithCredential(credential);
      return await _getOrCreateUserDoc(
        userCredential.user!,
        referralCode: referralCode,
      );
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    }
  }

  Future<UserModel?> _getOrCreateUserDoc(
    User user, {
    String? referralCode,
  }) async {
    final doc = await _firestore
        .collection(AppConstants.usersCollection)
        .doc(user.uid)
        .get();

    if (doc.exists) {
      // Update last seen
      await _firestore
          .collection(AppConstants.usersCollection)
          .doc(user.uid)
          .update({'lastSeen': FieldValue.serverTimestamp()});
      return UserModel.fromFirestore(doc);
    } else {
      return await _createUserDocument(
        user,
        referralCode: referralCode,
      );
    }
  }

  // Forgot Password
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    }
  }

  // Sign Out
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }

  // Get current user data
  Future<UserModel?> getCurrentUserData() async {
    final user = _auth.currentUser;
    if (user == null) return null;

    final doc = await _firestore
        .collection(AppConstants.usersCollection)
        .doc(user.uid)
        .get();

    if (doc.exists) return UserModel.fromFirestore(doc);
    return null;
  }

  // Stream current user data
  Stream<UserModel?> streamCurrentUser() {
    final user = _auth.currentUser;
    if (user == null) return Stream.value(null);

    return _firestore
        .collection(AppConstants.usersCollection)
        .doc(user.uid)
        .snapshots()
        .map((doc) => doc.exists ? UserModel.fromFirestore(doc) : null);
  }

  String _handleAuthException(FirebaseAuthException e) {
    switch (e.code) {
      case 'weak-password':
        return 'Password is too weak. Use at least 6 characters.';
      case 'email-already-in-use':
        return 'An account already exists with this email.';
      case 'invalid-email':
        return 'Invalid email address.';
      case 'user-not-found':
        return 'No account found with this email.';
      case 'wrong-password':
        return 'Incorrect password.';
      case 'too-many-requests':
        return 'Too many attempts. Please try again later.';
      case 'network-request-failed':
        return 'Network error. Check your connection.';
      default:
        return e.message ?? 'Authentication failed. Please try again.';
    }
  }
}
