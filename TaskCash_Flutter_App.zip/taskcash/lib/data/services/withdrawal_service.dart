// lib/data/services/withdrawal_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/transaction_model.dart';
import '../models/user_model.dart';
import '../../core/constants/app_constants.dart';

class WithdrawalService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String get _uid => _auth.currentUser!.uid;

  Future<void> requestWithdrawal({
    required UserModel user,
    required double amount,
    required String method,
    required String accountDetails,
  }) async {
    if (amount < AppConstants.minWithdrawalAmount) {
      throw 'Minimum withdrawal amount is ₹${AppConstants.minWithdrawalAmount}';
    }
    if (amount > AppConstants.maxWithdrawalAmount) {
      throw 'Maximum withdrawal amount is ₹${AppConstants.maxWithdrawalAmount}';
    }

    final coinsRequired = (amount * 100).toInt();
    if (user.totalCoins < coinsRequired) {
      throw 'Insufficient balance. You need ${coinsRequired} coins.';
    }

    // Check for pending withdrawals
    final pendingSnap = await _firestore
        .collection(AppConstants.withdrawalsCollection)
        .where('userId', isEqualTo: _uid)
        .where('status', isEqualTo: WithdrawalStatus.pending)
        .get();

    if (pendingSnap.docs.isNotEmpty) {
      throw 'You already have a pending withdrawal request.';
    }

    final batch = _firestore.batch();

    // Deduct coins from user
    final userRef =
        _firestore.collection(AppConstants.usersCollection).doc(_uid);
    batch.update(userRef, {
      'totalCoins': FieldValue.increment(-coinsRequired),
    });

    // Create withdrawal request
    final withdrawalRef =
        _firestore.collection(AppConstants.withdrawalsCollection).doc();
    batch.set(withdrawalRef, {
      'userId': _uid,
      'userName': user.name,
      'userEmail': user.email,
      'amount': amount,
      'coins': coinsRequired,
      'method': method,
      'accountDetails': accountDetails,
      'status': WithdrawalStatus.pending,
      'createdAt': FieldValue.serverTimestamp(),
    });

    // Add transaction record
    final txRef =
        _firestore.collection(AppConstants.transactionsCollection).doc();
    batch.set(txRef, {
      'userId': _uid,
      'type': TransactionType.withdrawn,
      'coins': -coinsRequired,
      'description': 'Withdrawal requested - ₹${amount.toStringAsFixed(2)}',
      'createdAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();
  }

  Stream<List<WithdrawalModel>> getUserWithdrawals() {
    return _firestore
        .collection(AppConstants.withdrawalsCollection)
        .where('userId', isEqualTo: _uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) =>
            snap.docs.map((doc) => WithdrawalModel.fromFirestore(doc)).toList());
  }

  // Admin: Get all withdrawals
  Stream<List<WithdrawalModel>> getAllWithdrawals({String? status}) {
    Query query = _firestore
        .collection(AppConstants.withdrawalsCollection)
        .orderBy('createdAt', descending: true);

    if (status != null) {
      query = query.where('status', isEqualTo: status);
    }

    return query.snapshots().map((snap) =>
        snap.docs.map((doc) => WithdrawalModel.fromFirestore(doc)).toList());
  }

  // Admin: Approve withdrawal
  Future<void> approveWithdrawal(
      String withdrawalId, String transactionId) async {
    await _firestore
        .collection(AppConstants.withdrawalsCollection)
        .doc(withdrawalId)
        .update({
      'status': WithdrawalStatus.approved,
      'processedAt': FieldValue.serverTimestamp(),
      'transactionId': transactionId,
    });
  }

  // Admin: Reject withdrawal
  Future<void> rejectWithdrawal(
      String withdrawalId, String reason, String userId, int coins) async {
    final batch = _firestore.batch();

    batch.update(
      _firestore
          .collection(AppConstants.withdrawalsCollection)
          .doc(withdrawalId),
      {
        'status': WithdrawalStatus.rejected,
        'processedAt': FieldValue.serverTimestamp(),
        'rejectionReason': reason,
      },
    );

    // Refund coins
    batch.update(
      _firestore.collection(AppConstants.usersCollection).doc(userId),
      {'totalCoins': FieldValue.increment(coins)},
    );

    // Add refund transaction
    final txRef =
        _firestore.collection(AppConstants.transactionsCollection).doc();
    batch.set(txRef, {
      'userId': userId,
      'type': 'refund',
      'coins': coins,
      'description': 'Withdrawal rejected - coins refunded',
      'createdAt': FieldValue.serverTimestamp(),
    });

    await batch.commit();
  }
}
