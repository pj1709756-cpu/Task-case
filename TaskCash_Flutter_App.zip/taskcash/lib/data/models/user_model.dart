// lib/data/models/user_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String email;
  final String name;
  final String? photoUrl;
  final String? phoneNumber;
  final int totalCoins;
  final int todayCoins;
  final int totalEarnings; // in paise
  final int referralCoins;
  final String referralCode;
  final String? referredBy;
  final int referralCount;
  final bool isAdmin;
  final bool isVerified;
  final bool isActive;
  final DateTime createdAt;
  final DateTime lastSeen;
  final DateTime? lastCheckIn;
  final String? fcmToken;
  final int level;
  final int streak;

  UserModel({
    required this.uid,
    required this.email,
    required this.name,
    this.photoUrl,
    this.phoneNumber,
    this.totalCoins = 0,
    this.todayCoins = 0,
    this.totalEarnings = 0,
    this.referralCoins = 0,
    required this.referralCode,
    this.referredBy,
    this.referralCount = 0,
    this.isAdmin = false,
    this.isVerified = false,
    this.isActive = true,
    required this.createdAt,
    required this.lastSeen,
    this.lastCheckIn,
    this.fcmToken,
    this.level = 1,
    this.streak = 0,
  });

  double get balanceInRupees => totalCoins / 100.0;
  double get todayEarningsInRupees => todayCoins / 100.0;
  double get totalEarningsInRupees => totalEarnings / 100.0;
  double get referralEarningsInRupees => referralCoins / 100.0;

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: doc.id,
      email: data['email'] ?? '',
      name: data['name'] ?? 'User',
      photoUrl: data['photoUrl'],
      phoneNumber: data['phoneNumber'],
      totalCoins: (data['totalCoins'] ?? 0).toInt(),
      todayCoins: (data['todayCoins'] ?? 0).toInt(),
      totalEarnings: (data['totalEarnings'] ?? 0).toInt(),
      referralCoins: (data['referralCoins'] ?? 0).toInt(),
      referralCode: data['referralCode'] ?? '',
      referredBy: data['referredBy'],
      referralCount: (data['referralCount'] ?? 0).toInt(),
      isAdmin: data['isAdmin'] ?? false,
      isVerified: data['isVerified'] ?? false,
      isActive: data['isActive'] ?? true,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      lastSeen: (data['lastSeen'] as Timestamp?)?.toDate() ?? DateTime.now(),
      lastCheckIn: (data['lastCheckIn'] as Timestamp?)?.toDate(),
      fcmToken: data['fcmToken'],
      level: (data['level'] ?? 1).toInt(),
      streak: (data['streak'] ?? 0).toInt(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'email': email,
      'name': name,
      'photoUrl': photoUrl,
      'phoneNumber': phoneNumber,
      'totalCoins': totalCoins,
      'todayCoins': todayCoins,
      'totalEarnings': totalEarnings,
      'referralCoins': referralCoins,
      'referralCode': referralCode,
      'referredBy': referredBy,
      'referralCount': referralCount,
      'isAdmin': isAdmin,
      'isVerified': isVerified,
      'isActive': isActive,
      'createdAt': Timestamp.fromDate(createdAt),
      'lastSeen': Timestamp.fromDate(lastSeen),
      'lastCheckIn': lastCheckIn != null ? Timestamp.fromDate(lastCheckIn!) : null,
      'fcmToken': fcmToken,
      'level': level,
      'streak': streak,
    };
  }

  UserModel copyWith({
    String? name,
    String? photoUrl,
    String? phoneNumber,
    int? totalCoins,
    int? todayCoins,
    int? totalEarnings,
    int? referralCoins,
    int? referralCount,
    bool? isVerified,
    bool? isActive,
    DateTime? lastSeen,
    DateTime? lastCheckIn,
    String? fcmToken,
    int? level,
    int? streak,
  }) {
    return UserModel(
      uid: uid,
      email: email,
      name: name ?? this.name,
      photoUrl: photoUrl ?? this.photoUrl,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      totalCoins: totalCoins ?? this.totalCoins,
      todayCoins: todayCoins ?? this.todayCoins,
      totalEarnings: totalEarnings ?? this.totalEarnings,
      referralCoins: referralCoins ?? this.referralCoins,
      referralCode: referralCode,
      referredBy: referredBy,
      referralCount: referralCount ?? this.referralCount,
      isAdmin: isAdmin,
      isVerified: isVerified ?? this.isVerified,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      lastSeen: lastSeen ?? this.lastSeen,
      lastCheckIn: lastCheckIn ?? this.lastCheckIn,
      fcmToken: fcmToken ?? this.fcmToken,
      level: level ?? this.level,
      streak: streak ?? this.streak,
    );
  }
}
