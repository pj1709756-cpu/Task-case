// lib/data/models/task_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class TaskModel {
  final String id;
  final String title;
  final String description;
  final String type;
  final int coins;
  final int? timeLimit; // seconds
  final bool isActive;
  final int completionCount;
  final int? maxCompletions;
  final DateTime createdAt;
  final String? imageUrl;
  final Map<String, dynamic>? extraData; // quiz questions, etc.
  final int difficulty; // 1-5
  final String? category;

  TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.coins,
    this.timeLimit,
    this.isActive = true,
    this.completionCount = 0,
    this.maxCompletions,
    required this.createdAt,
    this.imageUrl,
    this.extraData,
    this.difficulty = 1,
    this.category,
  });

  factory TaskModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return TaskModel(
      id: doc.id,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      type: data['type'] ?? 'daily',
      coins: (data['coins'] ?? 0).toInt(),
      timeLimit: data['timeLimit']?.toInt(),
      isActive: data['isActive'] ?? true,
      completionCount: (data['completionCount'] ?? 0).toInt(),
      maxCompletions: data['maxCompletions']?.toInt(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      imageUrl: data['imageUrl'],
      extraData: data['extraData'] as Map<String, dynamic>?,
      difficulty: (data['difficulty'] ?? 1).toInt(),
      category: data['category'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'description': description,
      'type': type,
      'coins': coins,
      'timeLimit': timeLimit,
      'isActive': isActive,
      'completionCount': completionCount,
      'maxCompletions': maxCompletions,
      'createdAt': Timestamp.fromDate(createdAt),
      'imageUrl': imageUrl,
      'extraData': extraData,
      'difficulty': difficulty,
      'category': category,
    };
  }
}

class UserTaskModel {
  final String id;
  final String userId;
  final String taskId;
  final bool isCompleted;
  final DateTime? completedAt;
  final int coinsEarned;

  UserTaskModel({
    required this.id,
    required this.userId,
    required this.taskId,
    this.isCompleted = false,
    this.completedAt,
    this.coinsEarned = 0,
  });

  factory UserTaskModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserTaskModel(
      id: doc.id,
      userId: data['userId'] ?? '',
      taskId: data['taskId'] ?? '',
      isCompleted: data['isCompleted'] ?? false,
      completedAt: (data['completedAt'] as Timestamp?)?.toDate(),
      coinsEarned: (data['coinsEarned'] ?? 0).toInt(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'taskId': taskId,
      'isCompleted': isCompleted,
      'completedAt': completedAt != null ? Timestamp.fromDate(completedAt!) : null,
      'coinsEarned': coinsEarned,
    };
  }
}
