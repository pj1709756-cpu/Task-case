// lib/data/models/transaction_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class TransactionModel {
  final String id;
  final String userId;
  final String type;
  final int coins;
  final String description;
  final DateTime createdAt;
  final String? taskId;
  final String? referralUserId;

  TransactionModel({
    required this.id,
    required this.userId,
    required this.type,
    required this.coins,
    required this.description,
    required this.createdAt,
    this.taskId,
    this.referralUserId,
  });

  double get amountInRupees => coins / 100.0;
  bool get isCredit => coins > 0;

  factory TransactionModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return TransactionModel(
      id: doc.id,
      userId: data['userId'] ?? '',
      type: data['type'] ?? '',
      coins: (data['coins'] ?? 0).toInt(),
      description: data['description'] ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      taskId: data['taskId'],
      referralUserId: data['referralUserId'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'type': type,
      'coins': coins,
      'description': description,
      'createdAt': Timestamp.fromDate(createdAt),
      'taskId': taskId,
      'referralUserId': referralUserId,
    };
  }
}

class WithdrawalModel {
  final String id;
  final String userId;
  final String userName;
  final String userEmail;
  final double amount;
  final int coins;
  final String method;
  final String accountDetails; // UPI ID, card number, etc.
  final String status;
  final DateTime createdAt;
  final DateTime? processedAt;
  final String? rejectionReason;
  final String? transactionId;

  WithdrawalModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userEmail,
    required this.amount,
    required this.coins,
    required this.method,
    required this.accountDetails,
    this.status = 'pending',
    required this.createdAt,
    this.processedAt,
    this.rejectionReason,
    this.transactionId,
  });

  factory WithdrawalModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return WithdrawalModel(
      id: doc.id,
      userId: data['userId'] ?? '',
      userName: data['userName'] ?? '',
      userEmail: data['userEmail'] ?? '',
      amount: (data['amount'] ?? 0.0).toDouble(),
      coins: (data['coins'] ?? 0).toInt(),
      method: data['method'] ?? '',
      accountDetails: data['accountDetails'] ?? '',
      status: data['status'] ?? 'pending',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      processedAt: (data['processedAt'] as Timestamp?)?.toDate(),
      rejectionReason: data['rejectionReason'],
      transactionId: data['transactionId'],
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'userName': userName,
      'userEmail': userEmail,
      'amount': amount,
      'coins': coins,
      'method': method,
      'accountDetails': accountDetails,
      'status': status,
      'createdAt': Timestamp.fromDate(createdAt),
      'processedAt': processedAt != null ? Timestamp.fromDate(processedAt!) : null,
      'rejectionReason': rejectionReason,
      'transactionId': transactionId,
    };
  }

  WithdrawalModel copyWith({
    String? status,
    DateTime? processedAt,
    String? rejectionReason,
    String? transactionId,
  }) {
    return WithdrawalModel(
      id: id,
      userId: userId,
      userName: userName,
      userEmail: userEmail,
      amount: amount,
      coins: coins,
      method: method,
      accountDetails: accountDetails,
      status: status ?? this.status,
      createdAt: createdAt,
      processedAt: processedAt ?? this.processedAt,
      rejectionReason: rejectionReason ?? this.rejectionReason,
      transactionId: transactionId ?? this.transactionId,
    );
  }
}
